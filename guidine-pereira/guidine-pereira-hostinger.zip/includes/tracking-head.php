<?php
/* Tracking tags. Each one only prints when its ID is set in config.php. */
if (GTM_ID): ?>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','<?= e(GTM_ID) ?>');</script>
<?php endif;
if (GA4_ID || GOOGLE_ADS_ID): ?>
<script async src="https://www.googletagmanager.com/gtag/js?id=<?= e(GA4_ID ?: GOOGLE_ADS_ID) ?>"></script>
<script>
window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());
<?php if (GA4_ID): ?>gtag('config','<?= e(GA4_ID) ?>');<?php endif; ?>
<?php if (GOOGLE_ADS_ID): ?>gtag('config','<?= e(GOOGLE_ADS_ID) ?>');<?php endif; ?>
</script>
<?php endif;
if (META_PIXEL_ID): ?>
<script>!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');fbq('init','<?= e(META_PIXEL_ID) ?>');fbq('track','PageView');</script>
<noscript><img height="1" width="1" style="display:none" alt="" src="https://www.facebook.com/tr?id=<?= e(META_PIXEL_ID) ?>&ev=PageView&noscript=1"></noscript>
<?php endif; ?>
